package xyz.clevertech.www.bitcoinvalue;


import android.app.Activity;

public class MyExceptionHandler implements Thread.UncaughtExceptionHandler {
    private Activity activity;

    public MyExceptionHandler(Activity a) {
        activity = a;
        //Logr.d("Setting Uncaught Exception handler");
    }
    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        //do your life saving stuff here
    }
}