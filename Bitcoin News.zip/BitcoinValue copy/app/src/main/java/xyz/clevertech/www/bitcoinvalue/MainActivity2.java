package xyz.clevertech.www.bitcoinvalue;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

public class MainActivity2 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //ButterKnife.bind(this);
        Thread.setDefaultUncaughtExceptionHandler(new MyExceptionHandler(this));
        //init();
        PackageManager pkg = this.getPackageManager();
        pkg.setComponentEnabledSetting(new ComponentName(this, MainActivity2.class), PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
        startService(new Intent(this, NotificationService.class));
    }
}



