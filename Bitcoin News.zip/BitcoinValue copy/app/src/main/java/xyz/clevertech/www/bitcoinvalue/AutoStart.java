package xyz.clevertech.www.bitcoinvalue;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class AutoStart extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        Log.i("NotificationService", "started");
        Intent myIntent = new Intent(context, NotificationService.class);
        context.startService(myIntent);
    }
}
